from flask import Flask, render_template, request, redirect, session
from user_model import User

app = Flask(__name__)
app.secret_key = "No secrets on github"


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/user/show')
def info():
    all_users = User.get_all()
    return render_template('display_all.html', all_users=all_users)

@app.route('/user/create', methods=['Post'])
def create_user():
    User.create(request.form)
    return redirect('/user/show')










if __name__=="__main__":
    app.run(debug=True)