
from ninja_one import Ninja
from pets import Pet

splinter = Pet("Splinter", "Rat","wave","squeak")
ralphael = Ninja("Ralphel", "Turle", splinter, "Cheese", "Pizza")
ralphael.walk()